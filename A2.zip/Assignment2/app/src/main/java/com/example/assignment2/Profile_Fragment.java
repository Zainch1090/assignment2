package com.example.assignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class Profile_Fragment extends Fragment {

    TextView tvUsername, tvEmail, tvPassword;

    public Profile_Fragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_profile_, container, false);


        tvUsername = rootView.findViewById(R.id.tvUsername);
        tvEmail = rootView.findViewById(R.id.tvEmail);
        tvPassword = rootView.findViewById(R.id.tvPassword);

       loadPreferences();

        return rootView;
    }

    private void loadPreferences() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "N/A");
        String email = sharedPreferences.getString("email", "N/A");
        String password = sharedPreferences.getString("password", "N/A");


        tvUsername.setText("Username: " + username);
        tvEmail.setText("Email: " + email);
        tvPassword.setText("Password: " + password);
    }
}
