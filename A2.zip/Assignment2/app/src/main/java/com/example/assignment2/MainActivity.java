package com.example.assignment2;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment; // Import Fragment class
import androidx.fragment.app.FragmentTransaction; // Import FragmentTransaction class

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.btnGoToSettings);
        btn2 = findViewById(R.id.btnGoToProfile);

        btn1.setOnClickListener(v -> openFragment(new Setting_Fragment())); // Open settings fragment
        btn2.setOnClickListener(v -> openFragment(new Profile_Fragment())); // Open profile fragment
    }

    void openFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment); // Replace current fragment with new one
        transaction.addToBackStack(null); // Add transaction to back stack for navigation
        transaction.commit(); // Commit the transaction
    }
}
