package com.example.assignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText; // Import EditText class
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class Setting_Fragment extends Fragment {

    EditText edtUsername, edtEmail, edtPassword;
    Button btnSavePreferences, btnResetPreferences;

    public Setting_Fragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_setting_, container, false);

        edtUsername = rootView.findViewById(R.id.edtUsername);
        edtEmail = rootView.findViewById(R.id.edtEmail);
        edtPassword = rootView.findViewById(R.id.edtPassword);
        btnSavePreferences = rootView.findViewById(R.id.btnSavePreferences);
        btnResetPreferences = rootView.findViewById(R.id.btnResetPreferences);


        loadPreferences();

        btnSavePreferences.setOnClickListener(v -> savePreferences());
        btnResetPreferences.setOnClickListener(v -> resetPreferences());

        return rootView;
    }

    private void loadPreferences() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "");
        String email = sharedPreferences.getString("email", "");
        String password = sharedPreferences.getString("password", "");

        edtUsername.setText(username);
        edtEmail.setText(email);
        edtPassword.setText(password);
    }

    private void savePreferences() {
        String username = edtUsername.getText().toString();
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();


        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(getActivity(), "All fields must be filled", Toast.LENGTH_SHORT).show();
        } else {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("username", username);
            editor.putString("email", email);
            editor.putString("password", password);
            editor.apply(); // Save data to SharedPreferences

            Toast.makeText(getActivity(), "Preferences saved successfully", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetPreferences() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // Clears all preferences
        editor.apply(); // Apply changes


        edtUsername.setText("");
        edtEmail.setText("");
        edtPassword.setText("");

        Toast.makeText(getActivity(), "Preferences reset successfully", Toast.LENGTH_SHORT).show();
    }
}
